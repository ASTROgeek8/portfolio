import generate as gen
import random

loop = True

print("Welcome to the ASCII Art Generator")
while loop:
    
    class House:
        roof = gen.gen_roof()
        base = [
            "|_|_|_|_|_|_|_|| ",
            "||_|_|_|_|_|_|_| ",
            "|_|_|_|_|_|_|_|| ",
            "||_|_||  |_|_|_| ",
            "|_|_|_|  ||_|_|| ",
            "|____ |__|_____| "]
        house_info = "Here is a house and it took " + str(len(roof) + len(base)) + " lines to make it."

    class Note:
        note = gen.gen_note()
        note_info = "Here is a music note and it took " + str(len(note)) + " lines to make it."

    class Car:
        car = gen.gen_car()
        car_info = "Here is a car and it took " + str(len(car)) + " lines to make it."

    class Sword:
        sword = gen.gen_sword()
        sword_info = "Here is a sword and it took " + str(len(sword)) + " lines to make it."

    class Pattern:
        hex_pattern = gen.gen_hex_pattern()
        dia_pattern = gen.gen_dia_pattern()
        squ_pattern = gen.gen_squ_pattern()
        hex_pattern_info = "Here is a pattern and it took " + str(len(hex_pattern)) + " lines to make it."
        dia_pattern_info = "Here is a pattern and it took " + str(len(dia_pattern)) + " lines to make it."
        squ_pattern_info = "Here is a pattern and it took " + str(len(squ_pattern)) + " lines to make it."

    choice = input("Type in a keyword. Here are some options('house', 'note', 'car', 'sword', 'pattern', 'i'm feeling lucky')")

    if choice == "house":
        p1 = House()
        for i in p1.roof:
            print(i)
        for i in p1.base:
            print(i)
        print(p1.house_info)
    
    elif choice == "note":
        p1 = Note()
        for i in p1.note:
            print(i)
        print(p1.note_info)
     
    elif choice == "car":
        p1 = Car()
        for i in p1.car:
            print(i)
        print(p1.car_info)
        
    elif choice == "sword":
        p1 = Sword()
        for i in p1.sword:
            print(i)
        print(p1.sword_info)
        
    elif choice == "pattern":
        outline = input("Select a pattern ouline.(hexagon, diamond, square)")
        if outline == "hexagon":
            p1 = Pattern()
            for i in p1.hex_pattern:
                print(i)
            print(p1.hex_pattern_info)
            
        elif outline == "diamond":
            p1 = Pattern()
            for i in p1.dia_pattern:
                print(i)
            print(p1.dia_pattern_info)
            
        elif outline == "square":
            p1 = Pattern()
            for i in p1.squ_pattern:
                print(i)
            print(p1.squ_pattern_info)
            
    elif choice == "i'm feeling lucky":
        num = random.randint(1, 5)
        
        if num == 1:
            p1 = House()
            for i in p1.roof:
                print(i)
            for i in p1.base:
                print(i)
            print(p1.house_info)
            
        elif num == 2:
            p1 = Note()
            for i in p1.note:
                print(i)
            print(p1.note_info)
            
        elif num == 3:
            p1 = Car()
            for i in p1.car:
                print(i)
            print(p1.car_info)
            
        elif num == 4:
            p1 = Sword()
            for i in p1.sword:
                print(i)
            print(p1.sword_info)
            
        elif num == 5:
            rand_num = random.randint(1,3)
            
            if rand_num == 1:
                p1 = Pattern()
                for i in p1.hex_pattern:
                    print(i)
                print(p1.hex_pattern_info)
                
            elif rand_num == 2:
                p1 = Pattern()
                for i in p1.dia_pattern:
                    print(i)
                print(p1.dia_pattern_info)
                
            elif rand_num == 3:
                p1 = Pattern()
                for i in p1.squ_pattern:
                    print(i)
                print(p1.squ_pattern_info)
    else:
        print("invalid feedback")

    again = input("Do you want to try again? y/n ")
    if again == "y":
        continue
    if again == "n":
        break
    
feedback = input("Please leave a review for this program... ")
print("Thanks for your feedback")
